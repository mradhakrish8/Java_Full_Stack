use mydb;

create table account(accno int,lastname varchar(25),firstname varchar(25),bal int)

select * from account;